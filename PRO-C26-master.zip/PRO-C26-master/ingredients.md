INGREDIENTS:


FOR THE SAUCE

1/3 c. low-sodium soy sauce

2 tbsp. rice wine vinegar

1 tsp. sesame oil

1 1/2 tbsp. honey

2 cloves garlic, minced

2 tsp. finely minced fresh ginger

2 tsp. cornstarch


FOR THE CHICKEN

1 tbsp. vegetable oil

1 lb. boneless skinless chicken breasts, cut into 1" pieces

Kosher salt

Freshly ground black pepper

Sesame seeds, for garnish

Sliced green onions, for garnish

Cooked white rice, for serving

Steamed broccoli, for serving
