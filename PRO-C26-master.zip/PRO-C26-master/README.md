# Project 26: Masterchef Jr.
Teriyaki Chicken Recipe

Made by Rishi Venkatesh

Link: https://ethyx.github.io/PRO-C26/
